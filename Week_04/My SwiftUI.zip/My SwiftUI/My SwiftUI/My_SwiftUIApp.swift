//
//  My_SwiftUIApp.swift
//  My SwiftUI
//
//  Created by J Rogel PhD on 07/09/2022.
//

import SwiftUI

@main
struct My_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
//            Challenge_1()
        }
    }
}

